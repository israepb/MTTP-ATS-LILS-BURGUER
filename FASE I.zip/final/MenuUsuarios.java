import java.util.List;
public class MenuUsuarios{
    public static void mostrar(){
        boolean activo = true;
        while(activo){
            Consola.titulo("USUARIOS Y EMPLEADOS");
            System.out.println("  1. Ver todos los empleados");
            System.out.println("  2. Agregar empleado");
            System.out.println("  3. Desactivar usuario");
            System.out.println("  0. Volver");
            Consola.linea();
            int op = Consola.leerEntero("Opcion");
            switch(op){
                case 1: 
                    verEmpleados(); 
                    break;
                case 2: 
                    agregarEmpleado(); 
                    break;
                case 3: 
                    desactivarUsuario(); 
                    break;
                case 0: 
                    activo=false; 
                    break;
                default: System.out.println("  Opcion no valida."); 
                    break;
            }
        }
    }
    private static void verEmpleados(){
        Consola.titulo("EMPLEADOS");
        List<Usuario> lista = UsuarioDAO.listarTodos();
        if(lista.isEmpty()){
            System.out.println("  Sin usuarios registrados.");
        }else{
            for(Usuario u : lista){ 
                System.out.println("  " + u); 
            }
        }
        Consola.pausar();
    }
    private static void agregarEmpleado(){
        Consola.titulo("AGREGAR EMPLEADO");
        String nombre = Consola.leerTexto("Nombre");
        String apellido = Consola.leerTexto("Apellido");
        String telefono = Consola.leerTexto("Telefono");
        String usuario = Consola.leerTexto("Nombre de usuario");
        String contra = Consola.leerTexto("Contrasena");
        String rol;
        while(true){
            System.out.println("  Roles disponibles: ADMIN | CAJERO | COCINERO");
            rol=Consola.leerTexto("Rol").toUpperCase().trim();
            if(rol.equals(Usuario.ADMIN) || rol.equals(Usuario.CAJERO) || rol.equals(Usuario.COCINERO)){
                break;
            }
            System.out.println("  Rol no valido. Ingrese exactamente: ADMIN, CAJERO o COCINERO.");
        }
        String id = UsuarioDAO.siguienteId();
        Usuario u = new Usuario(id, nombre, apellido, telefono, usuario, contra, rol);
        UsuarioDAO.guardar(u);
        System.out.println("  Empleado registrado: " + id + " | " + rol);
        Consola.pausar();
    }
    private static void desactivarUsuario(){
        String id=Consola.leerTexto("ID del usuario");
        Usuario u=UsuarioDAO.buscar(id);
        if(u==null){ 
            System.out.println("  Usuario no encontrado."); 
            Consola.pausar(); 
            return;
        }
        if(Consola.confirmar("Desactivar a " + u.getNombre() + "?")){
            u.setActivo(false);
            UsuarioDAO.guardar(u);
            System.out.println("  Usuario desactivado.");
        }
        Consola.pausar();
    }
}