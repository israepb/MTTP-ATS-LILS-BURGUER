package lilsburguer.model;

import java.util.ArrayList;

public class Factura {
    private int idFactura;
    private String nit;
    private String razonSocial;
    private double totalPagar;

    // Estructura de datos: Lista para guardar todas las facturas del día
    public static ArrayList<Factura> historialFacturas = new ArrayList<>();

    public Factura(int idFactura, String nit, String razonSocial, double totalPagar) {
        this.idFactura = idFactura;
        this.nit = nit;
        this.razonSocial = razonSocial;
        this.totalPagar = totalPagar;
    }

    public void guardarFactura() {
        historialFacturas.add(this);
    }
}