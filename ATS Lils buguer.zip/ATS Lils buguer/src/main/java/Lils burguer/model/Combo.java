package lilsburguer.model;

import java.util.ArrayList;
import java.util.List;

public class Combo {
    private int idCombo;
    private String nombre;
    private double precioEspecial;
    private List<String> listaProductos; 

    public Combo(int idCombo, String nombre, double precioEspecial) {
        this.idCombo = idCombo;
        this.nombre = nombre;
        this.precioEspecial = precioEspecial;
        this.listaProductos = new ArrayList<>();
    }

    public void agregarProducto(String producto) {
        this.listaProductos.add(producto);
    }
}