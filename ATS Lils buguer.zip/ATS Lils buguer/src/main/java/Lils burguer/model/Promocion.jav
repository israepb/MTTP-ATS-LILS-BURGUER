package lilsburguer.model;

public class Promocion {
    private int idPromocion;
    private String descripcion;
    private double descuento;
    private String fechaInicio;
    private String fechaFin;

    public Promocion(int idPromocion, String descripcion, double descuento, String fechaInicio, String fechaFin) {
        this.idPromocion = idPromocion;
        this.descripcion = descripcion;
        this.descuento = descuento;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public String getDetalles() {
        return "Promo: " + descripcion + " (-" + descuento + "%)";
    }
}