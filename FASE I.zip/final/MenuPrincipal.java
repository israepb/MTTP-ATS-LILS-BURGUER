public class MenuPrincipal{
    static Usuario sesion=null;
    static boolean tieneRol(String... roles){
        if(sesion==null){ 
            return false; 
        }
        for(String r : roles){
            if(sesion.getRol().equals(r)){ 
                return true; 
            }
        }
        return false;
    }
    public static void mostrar(){
        boolean ejecutando=true;
        while(ejecutando){
            System.out.println();
            System.out.println("  ================================================");
            System.out.println("       LILS BURGER - SISTEMA DE GESTION");
            System.out.println("       Av. Pando y Av. Portales | 17:00-23:30");
            System.out.println("  ================================================");
            if(sesion!=null){
                System.out.println("  >> Sesion: " + sesion.getNombre() + " " + sesion.getApellido() + " | Rol: " + sesion.getRol());
            }else{
                System.out.println("  >> Modo publico (sin sesion)");
            }
            System.out.println();
            System.out.println("  1. Productos y Menu");
            System.out.println("  2. Pedidos - Punto de Venta");
            System.out.println("  3. Inventario" + etiqueta(Usuario.COCINERO, Usuario.ADMIN));
            System.out.println("  4. Usuarios y Empleados" + etiqueta(Usuario.ADMIN));
            System.out.println("  5. Proveedores" + etiqueta(Usuario.ADMIN));
            System.out.println("  6. Reportes" + etiqueta(Usuario.CAJERO,  Usuario.ADMIN));
            if(sesion==null){
                System.out.println("  7. Iniciar sesion");
            }else{
                System.out.println("  7. Cerrar sesion [" + sesion.getNombreUsuario() + "]");
            }
            System.out.println("  0. Salir");
            Consola.linea();
            int op=Consola.leerEntero("Opcion");
            switch(op){
                case 1: MenuProductos.mostrar(); break;
                case 2: MenuPedidos.mostrar(); break;
                case 3:
                    if(verificar("COCINERO o ADMIN", Usuario.COCINERO, Usuario.ADMIN)){
                        MenuInventario.mostrar();
                    }
                    break;
                case 4:
                    if(verificar("ADMIN", Usuario.ADMIN)){
                        MenuUsuarios.mostrar();
                    }
                    break;
                case 5:
                    if(verificar("ADMIN", Usuario.ADMIN)){
                        MenuProveedores.mostrar();
                    }
                    break;
                case 6:
                    if(verificar("CAJERO o ADMIN", Usuario.CAJERO, Usuario.ADMIN)){
                        MenuReportes.mostrar();
                    }
                    break;
                case 7: gestionarSesion(); break;
                case 0:
                    System.out.println("\n  Hasta pronto! Lils Burger.");
                    ejecutando = false;
                    break;
                default: System.out.println("  Opcion no valida."); break;
            }
        }
    }
    private static String etiqueta(String... roles){
        if(tieneRol(roles)){ 
            return ""; 
        }
        String lista = String.join(" o ", roles);
        return "  [requiere: " + lista + "]";
    }
    static boolean verificar(String descripcion, String... roles){
        if(tieneRol(roles)){ 
            return true; 
        }
        System.out.println("  Seccion restringida. Requiere rol: " + descripcion);
        if(!Consola.confirmar("Desea iniciar sesion ahora?")){
            return false;
        }
        Usuario u = pedirLogin();
        if(u==null){ 
            return false; 
        }
        sesion=u;
        boolean acceso = tieneRol(roles);
        if(!acceso){
            System.out.println("  Acceso denegado: el rol " + sesion.getRol() + " no tiene permiso para esta seccion.");
            Consola.pausar();
        }
        return acceso;
    }
    static Usuario pedirLogin(){
        Consola.titulo("INICIAR SESION");
        String user = Consola.leerTexto("Usuario");
        String pass = Consola.leerTexto("Contrasena");
        Usuario u = UsuarioDAO.validarLogin(user, pass);
        if(u==null){
            System.out.println("  Usuario o contrasena incorrectos.");
            Consola.pausar();
            return null;
        }
        System.out.println("  Bienvenido, " + u.getNombre() + " | Rol: " + u.getRol());
        Consola.pausar();
        return u;
    }
    private static void gestionarSesion(){
        if(sesion==null){
            Usuario u = pedirLogin();
            if(u != null){ 
                sesion = u; 
            }
        }else{
            if(Consola.confirmar("Cerrar sesion de " + sesion.getNombre() + "?")){
                sesion = null;
                System.out.println("  Sesion cerrada.");
                Consola.pausar();
            }
        }
    }
}