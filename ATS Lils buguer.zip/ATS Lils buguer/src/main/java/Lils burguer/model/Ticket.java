package lilsburguer.model;

import java.util.LinkedList;
import java.util.Queue;

public class Ticket {
    private int idTicket;
    private int nroPedido;
    private String fechaEmision;

    // Estructura de datos: Cola para que los tickets se atiendan en orden
    public static Queue<Ticket> colaAtencion = new LinkedList<>();

    public Ticket(int idTicket, int nroPedido, String fechaEmision) {
        this.idTicket = idTicket;
        this.nroPedido = nroPedido;
        this.fechaEmision = fechaEmision;
    }

    public void registrarEnCocina() {
        colaAtencion.add(this);
    }
}